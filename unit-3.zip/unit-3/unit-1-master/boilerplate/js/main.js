//Contains the code inside one entire function.
(function () {

    //Creates an array of the titles states in the CSV.
    var attrArray = ["County", "X", "Y", "Pop_2024", "DWI_Num", "DWI_Crash", "DWI_Tot", "DWI_Rate", "DWI_Num_Rt", "DWI_Cr_Rt"];
    var expressed = attrArray[8]; //Selects the 9th column in the CSV to use as data.

    //Begins the script.
    window.onload = setMap;

    //Sets up the chloropleth map on the website.
    function setMap() {

        //Dimensions of the map.
        var width = window.innerWidth * 0.4,
            height = 460;

        //Creates the container for the map so it can be put on the webpage.
        var map = d3.select("body")
            .append("svg")
            .attr("class", "map")
            .attr("width", width)
            .attr("height", height);

        //Creates the projection for the map.
        var projection = d3.geoAlbers()
            .center([0, 40.96])
            .rotate([93.73, -5.45, 0])
            .parallels([29.5, 25.00])
            .scale(4500)
            .translate([width / 2, height / 2]);

        var path = d3.geoPath().projection(projection);

        //Loads the data that will be represented.
        var promises = [
            d3.csv("data/Base_Data.csv"),
            d3.json("data/MN_Counties.json")
        ];

        Promise.all(promises).then(function (data) {
            var csvData = data[0];
            var county = data[1];

            //Adds a graticule to the map.
            setGraticule(map, path);

            //Converts the topojson to the map.
            var Minnesota = topojson.feature(county, county.objects.MN_Counties).features;

            //Joins the CSV and JSON so the data can be represented.
            Minnesota = joinData(Minnesota, csvData);

            //Creates the color scale based off the data.
            var colorScale = makeColorScale(csvData);

            //Draws out the map with the color scale.
            setEnumerationUnits(Minnesota, map, path, colorScale);

            //Draws out the chart on the website with the color scale.
            setChart(csvData, colorScale);
        });
    }

    //Draws out the counties onto the map.
    function setEnumerationUnits(Minnesota, map, path, colorScale) {
        var regions = map.selectAll(".regions")
            .data(Minnesota)
            .enter()
            .append("path")
            .attr("class", function (d) {
                return "regions " + d.properties.adm1_code;
            })
            .attr("d", path)
            .style("fill", function (d) {
                var value = d.properties[expressed];
                return value || value === 0 ? colorScale(value) : "#ccc";
            });
    }

    //Creates the bar chart on the website.
    function setChart(csvData, colorScale) {
        var chartWidth = window.innerWidth * 0.4,
            chartHeight = 473,
            leftPadding = 25,
            rightPadding = 2,
            topBottomPadding = 5,
            chartInnerWidth = chartWidth - leftPadding - rightPadding,
            chartInnerHeight = chartHeight - topBottomPadding * 2,
            translate = "translate(" + leftPadding + "," + topBottomPadding + ")";

        var chart = d3.select("body")
            .append("svg")
            .attr("width", chartWidth)
            .attr("height", chartHeight)
            .attr("class", "chart");

        var chartBackground = chart.append("rect")
            .attr("class", "chartBackground")
            .attr("width", chartInnerWidth)
            .attr("height", chartInnerHeight)
            .attr("transform", translate);

        var yScale = d3.scaleLinear()
            .range([chartInnerHeight, 0])
            .domain([0, d3.max(csvData, function (d) { return parseFloat(d[expressed]); })]);

        var bars = chart.selectAll(".bar")
            .data(csvData)
            .enter()
            .append("rect")
            .sort(function (a, b) {
                return b[expressed] - a[expressed];
            })
            .attr("class", function (d) {
                return "bar " + d.adm1_code;
            })
            .attr("width", chartInnerWidth / csvData.length - 1)
            .attr("x", function (d, i) {
                return i * (chartInnerWidth / csvData.length) + leftPadding;
            })
            .attr("height", function (d) {
                return chartInnerHeight - yScale(parseFloat(d[expressed]));
            })
            .attr("y", function (d) {
                return yScale(parseFloat(d[expressed])) + topBottomPadding;
            })
            .style("fill", function (d) {
                return colorScale(d[expressed]);
            });

        chart.append("text")
            .attr("x", 40)
            .attr("y", 40)
            .attr("class", "chartTitle")
            .text("Number of DWI Incidents per County per 100k");

        var yAxis = d3.axisLeft().scale(yScale);

        chart.append("g")
            .attr("class", "axis")
            .attr("transform", translate)
            .call(yAxis);

        chart.append("rect")
            .attr("class", "chartFrame")
            .attr("width", chartInnerWidth)
            .attr("height", chartInnerHeight)
            .attr("transform", translate);
    }

    //Function that creates the color scale, coordinating colors with different values.
    function makeColorScale(data) {
        var colorClasses = [
            "#f3c0c0ff",
            "#f07f7fff",
            "#db3434ff",
            "#960f0fff",
            "#4e0505ff"
        ];

        var colorScale = d3.scaleThreshold().range(colorClasses);

        var domainArray = [];
        for (var i = 0; i < data.length; i++) {
            var val = parseFloat(data[i][expressed]);
            domainArray.push(val);
        }

        var clusters = ss.ckmeans(domainArray, 5);
        domainArray = clusters.map(function (d) { return d3.min(d); });
        domainArray.shift();

        colorScale.domain(domainArray);
        return colorScale;
    }

    //Draws out the graticule for the map.
    function setGraticule(map, path) {
        var graticule = d3.geoGraticule().step([5, 5]);

        map.append("path")
            .datum(graticule.outline())
            .attr("class", "gratBackground")
            .attr("d", path);

        map.selectAll(".gratLines")
            .data(graticule.lines())
            .enter()
            .append("path")
            .attr("class", "gratLines")
            .attr("d", path);
    }

    //Joins the CSV to the JSON to match variables to be represented.
    function joinData(Minnesota, csvData) {
        for (var i = 0; i < csvData.length; i++) {
            var csvRegion = csvData[i];
            var csvKey = csvRegion.County.trim().toLowerCase();

            for (var a = 0; a < Minnesota.length; a++) {
                var geojsonProps = Minnesota[a].properties;
                var geojsonKey = geojsonProps.NAME.trim().toLowerCase();

                if (geojsonKey === csvKey) {
                    attrArray.forEach(function (attr) {
                        var val = parseFloat(csvRegion[attr]);
                        geojsonProps[attr] = val;
                    });
                }
            }
        }
        return Minnesota;
    }

})();
    /*
    //SVG dimension variables
    var w = 900, h = 500;
    
    //Example 1.5 line 1...container block
    var container = d3.select("body") //get the <body> element from the DOM
        .append("svg") //put a new svg in the body
        .attr("width", w) //assign the width
        .attr("height", h) //assign the height
        .attr("class", "container") //assign a class name
        .style("background-color", "rgba(0,0,0,0.2)"); //svg background color
    
    //innerRect block
    var innerRect = container.append("rect")
        .datum(400) //a single value is a DATUM
        .attr("width", function (d) { //rectangle width
            return d * 2; //400 * 2 = 800
        })
        .attr("height", function (d) { //rectangle height
            return d; //400
        })
        .attr("class", "innerRect") //class name
        .attr("x", 50) //position from left on the x (horizontal) axis
        .attr("y", 50) //position from top on the y (vertical) axis
        .style("fill", "#FFFFFF"); //fill color
    
    //above Example 2.8 line 20
    //find the minimum value of the array
    var minPop = d3.min(cityPop, function (d) {
        return d.population;
    });
    
    //find the maximum value of the array
    var maxPop = d3.max(cityPop, function (d) {
        return d.population;
    });
    
    //Example 3.3 line 12...scale for circles center y coordinate
    var y = d3.scaleLinear()
        .range([450, 50]) //was 440, 95
        .domain([0, 700000]); //was minPop, maxPop
    
    var color = d3.scaleLinear()
        .range([
            "#FDBE85",
            "#D94701"
        ])
        .domain([
            minPop,
            maxPop
        ]);
    
    //Example 2.6 line 3
    var circles = container.selectAll(".circles") //create an empty selection
        .data(cityPop) //here we feed in an array
        .enter() //one of the great mysteries of the universe
        .append("circle") //inspect the HTML--holy crap, there's some circles there
        .attr("class", "circles")
        .attr("id", function (d) {
            return d.city;
        })
        .attr("r", function (d) {
            //calculate the radius based on population value as circle area
            var area = d.population * 0.01;
            return Math.sqrt(area / Math.PI);
        })
        .attr("cx", function (d, i) {
            //use the index to place each circle horizontally
            return 90 + (i * 180);
        })
        //Example 3.4 line 1
        .attr("cy", function (d) {
            return y(d.population);
        })
        .style("fill", function (d, i) { //add a fill based on the color scale generator
            return color(d.population);
        })
        .style("stroke", "#000"); //black circle stroke
    
    //Example 3.6 line 1...create y axis generator
    var yAxis = d3.axisLeft(y);
    
    //Example 3.8 line 1...create axis g element and add axis
    var axis = container.append("g")
        .attr("class", "axis")
        .attr("transform", "translate(50, 0)")
        .call(yAxis);
    
    //below Example 3.9...create a text element and add the title
    var title = container.append("text")
        .attr("class", "title")
        .attr("text-anchor", "middle")
        .attr("x", 450)
        .attr("y", 30)
        .text("City Populations");
    
    //Example 3.14 line 1...create circle labels
    var labels = container.selectAll(".labels")
        .data(cityPop)
        .enter()
        .append("text")
        .attr("class", "labels")
        .attr("text-anchor", "left")
        .attr("y", function (d) {
            //vertical position centered on each circle
            return y(d.population) + 0;
        });
    
    //first line of label
    var nameLine = labels.append("tspan")
        .attr("class", "nameLine")
        .attr("x", function (d, i) {
            return 90 + (i * 180) + Math.sqrt(d.population * 0.01 / Math.PI) + 5;
        })
        .text(function (d) {
            return d.city;
        });
    
    //create format generator
    var format = d3.format(",");
    
    //Example 3.16 line 1...second line of label
    var popLine = labels.append("tspan")
        .attr("class", "popLine")
        .attr("x", function (d, i) {
            return 90 + (i * 180) + Math.sqrt(d.population * 0.01 / Math.PI) + 5;
        })
        .attr("dy", "15") //vertical offset
        .text(function (d) {
            return "Pop. " + format(d.population); //use format generator to format numbers
        });
    
    console.log(innerRect);
    */
 //last line of main.js